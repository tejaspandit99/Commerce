A Pen created at CodePen.io. You can find this one at http://codepen.io/thebabydino/pen/dMaRYx.

 Idea from [this tweet](https://twitter.com/LeaVerou/status/729093777961287680) - minimum number of stops needed to recreate the shirt pattern.

>Fun flight. [@svgeesus](https://twitter.com/svgeesus) & I debated what's the min # of stops needed to make this guy's shirt pattern w/ CSS gradients
![shirt](https://pbs.twimg.com/media/Ch5C6-OUYAEbxRJ.jpg)
